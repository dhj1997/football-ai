"""Football AI API package."""

