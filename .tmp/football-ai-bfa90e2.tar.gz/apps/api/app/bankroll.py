"""Simulated bankroll placement rules and aggregate reporting."""

import uuid
from collections.abc import Mapping
from copy import deepcopy
from datetime import UTC, datetime
from typing import Any, Iterable

from .market_decision import assess_markets
from .portfolio import (
    BetCandidate,
    PortfolioConfig,
    build_candidates,
    calculate_drawdown,
    candidate_from_market_row,
    candidate_gate_reasons,
    exposure_snapshot,
    is_active_bet,
    risk_gate,
    select_best_candidates,
    select_portfolio,
)


INITIAL_BANKROLL = 1000.0


def _candidate_value(candidate: Any, key: str) -> Any:
    return candidate.get(key) if isinstance(candidate, Mapping) else getattr(candidate, key, None)


def _shrink_toward_market(probabilities: dict[str, Any], odds: Any, shrinkage: float) -> dict[str, Any]:
    """Blend baseline probabilities with the de-vig market prior."""

    if not isinstance(odds, Mapping) or shrinkage <= 0:
        return probabilities
    try:
        implied = {key: 1.0 / float(odds.get(key)) for key in ("home", "draw", "away")}
    except (TypeError, ValueError, ZeroDivisionError):
        return probabilities
    overround = sum(implied.values())
    if overround <= 0:
        return probabilities
    blended: dict[str, Any] = {}
    for key in ("home", "draw", "away"):
        market_probability = implied[key] / overround
        model_probability = float(probabilities.get(key) or 0)
        blended[key] = round((1.0 - shrinkage) * model_probability + shrinkage * market_probability, 4)
    total = sum(float(value) for value in blended.values())
    if total <= 0:
        return probabilities
    return {key: round(float(value) / total, 4) for key, value in blended.items()}


def _candidate_side(candidate: Any) -> str | None:
    market = str(_candidate_value(candidate, "market") or "")
    selection = str(_candidate_value(candidate, "selection") or "")
    if market == "asian_handicap":
        return "home" if "home" in selection else "away" if "away" in selection else None
    return selection if selection in {"home", "away", "draw"} else None


def _follows_ai_direction(prediction: dict[str, Any], candidate: Any) -> bool:
    """The Poisson baseline is a fallback calculator: it may express the AI's
    research direction, never contradict it (e.g. laying a clear favourite on
    thin xG data)."""

    predicted = str(
        (prediction.get("forecast") or {}).get("predicted_outcome")
        or prediction.get("predicted_outcome")
        or ""
    )
    side = _candidate_side(candidate)
    if not predicted or not side:
        return True
    return side == predicted


def _fixed_stake(value: Any) -> float | None:
    """Read the optional fixed stake used only by the automation path."""

    raw = value.get("automation_fixed_stake") if isinstance(value, Mapping) else None
    try:
        amount = float(raw)
    except (TypeError, ValueError):
        return None
    return round(amount, 2) if amount > 0 else None


class BankrollService:
    """Place bounded simulated bets from deterministic backend decisions."""

    def __init__(
        self,
        repository: Any,
        portfolio_config: PortfolioConfig | None = None,
        initial_bankroll: float = INITIAL_BANKROLL,
    ) -> None:
        self.repository = repository
        self.portfolio_config = portfolio_config or PortfolioConfig()
        self.initial_bankroll = max(0.0, float(initial_bankroll))
        self.model_key = "deepseek"
        self.competition_id = "legacy"
        self.uncapped = False

    def configure(self, model_key: str, competition_id: str, uncapped: bool = False) -> "BankrollService":
        self.model_key = model_key
        self.competition_id = competition_id
        self.uncapped = uncapped
        return self

    def place_for_prediction(
        self,
        prediction: dict[str, Any],
        fixture: dict[str, Any],
        context: dict[str, Any],
    ) -> dict[str, Any] | None:
        if fixture.get("status") != "scheduled" or _fixture_started(fixture):
            return None
        fixed_stake = _fixed_stake(context)
        if fixed_stake is not None:
            candidate = self.candidate_for_prediction(prediction, fixture, context)
            if candidate is None:
                return None
            return self.place_for_candidate(prediction, fixture, candidate, fixed_stake=fixed_stake)
        latest_reader = getattr(self.repository, "latest", None)
        latest = latest_reader(fixture["id"], self.model_key, self.competition_id) if callable(latest_reader) else None
        if latest is not None and latest.get("id") != prediction.get("id"):
            return None
        working_prediction = deepcopy(prediction)
        _complete_candidate_decision(working_prediction, context, self.repository)
        discard = getattr(self.repository, "discard_open_fixture_bets", None)
        if callable(discard):
            discard(fixture["id"], self.model_key, self.competition_id, working_prediction.get("id"))

        fixtures = self._league_day_fixtures(fixture)
        candidates = self._league_day_candidates(working_prediction, fixture, fixtures, context)
        group_bets = self._league_day_bets(fixture["fixture_date"], fixture.get("league_key"))
        if not candidates:
            return None

        selected_prediction, selected_fixture = candidates[0]
        locked = next((bet for bet in group_bets if bet.get("fixture_id") == fixture.get("id")), None)
        if locked:
            locked_candidate = next(
                (item for item in candidates if item[1].get("id") == fixture.get("id")),
                None,
            )
            if locked_candidate is None:
                return locked
            locked_prediction, locked_fixture = locked_candidate
            expected_stake = self._canonical_stake(
                locked_prediction.get("portfolio_candidate") or {},
                locked_fixture,
                exclude_bet_id=locked.get("id"),
            )
            if _bet_matches_candidate(locked, locked_prediction, expected_stake=expected_stake):
                return locked
            if callable(discard):
                discard(locked_fixture["id"], self.model_key, self.competition_id)
        existing_selected = self.repository.bet_for_prediction(selected_prediction["id"])
        if existing_selected and _bet_matches_candidate(existing_selected, selected_prediction):
            return existing_selected
        if existing_selected and callable(discard):
            discard(selected_fixture["id"], self.model_key, self.competition_id)
        return self._place_candidate(selected_prediction, selected_fixture)

    def candidate_for_prediction(
        self,
        prediction: dict[str, Any],
        fixture: dict[str, Any],
        context: dict[str, Any],
    ) -> Any | None:
        """Build one derived Portfolio candidate without persisting or mutating prediction."""

        working_prediction = deepcopy(prediction)
        _complete_candidate_decision(working_prediction, context, self.repository)
        candidates = build_candidates(
            working_prediction,
            fixture,
            self.portfolio_config,
            historical_clv=self._historical_clv(),
        )
        return candidates[0] if candidates else None

    def candidate_for_poisson(
        self,
        prediction: dict[str, Any],
        fixture: dict[str, Any],
        context: dict[str, Any],
    ) -> Any | None:
        """Build the existing Poisson baseline as a candidate-only input."""

        baseline = prediction.get("baseline") or {}
        probabilities = baseline.get("probabilities") or {}
        if not probabilities:
            return None
        shrunk = _shrink_toward_market(
            probabilities,
            (context.get("odds") or {}),
            self.portfolio_config.baseline_market_shrinkage,
        )
        working_prediction = deepcopy(prediction)
        working_prediction["model_key"] = "poisson"
        working_prediction["model_version"] = baseline.get("model_version") or "poisson-baseline"
        working_prediction["probabilities"] = deepcopy(shrunk)
        working_prediction["model_probabilities"] = deepcopy(shrunk)
        working_prediction["ai"] = {"status": "completed", "provider": "poisson"}
        working_prediction["forecast_confidence"] = 0.0
        working_prediction["decision"] = {
            **(working_prediction.get("decision") or {}),
            "model_confidence": 0.0,
        }
        _complete_candidate_decision(working_prediction, context, self.repository)
        candidates = build_candidates(
            working_prediction,
            fixture,
            self.portfolio_config,
            historical_clv=self._historical_clv(),
        )
        return candidates[0] if candidates else None

    def place_for_candidate(
        self,
        prediction: dict[str, Any],
        fixture: dict[str, Any],
        candidate: Any,
        fixed_stake: float | None = None,
    ) -> dict[str, Any] | None:
        """Execute one globally selected candidate without re-ranking its model peers."""

        if fixture.get("status") != "scheduled" or _fixture_started(fixture):
            return None
        payload = candidate.to_dict() if hasattr(candidate, "to_dict") else dict(candidate)
        working_prediction = deepcopy(prediction)
        working_prediction["portfolio_candidate"] = payload
        working_prediction["decision"] = {
            **(working_prediction.get("decision") or {}),
            "status": "bet",
            "market": payload.get("market"),
            "selection": payload.get("selection"),
        }
        if fixed_stake is not None:
            working_prediction["automation_fixed_stake"] = fixed_stake
        latest_reader = getattr(self.repository, "latest", None)
        latest = latest_reader(fixture["id"], self.model_key, self.competition_id) if callable(latest_reader) else None
        if latest is not None and latest.get("id") != prediction.get("id"):
            return None
        existing = self.repository.bet_for_prediction(prediction["id"])
        if existing and _bet_matches_candidate(existing, working_prediction, expected_stake=fixed_stake):
            return existing
        discard = getattr(self.repository, "discard_open_fixture_bets", None)
        if callable(discard):
            discard(fixture["id"], self.model_key, self.competition_id, prediction.get("id"))
        return self._place_portfolio_candidate(working_prediction, fixture)

    def execution_for_prediction(self, prediction: dict[str, Any], fixture: dict[str, Any]) -> dict[str, Any]:
        """Describe portfolio execution without mutating the immutable prediction.

        The decision was frozen when the prediction was generated; this read
        view reports the stable outcome (bet placed, or the frozen decision)
        instead of re-simulating gates against live data on every request.
        """

        decision = prediction.get("decision") or {}
        linked = self.repository.bet_for_prediction(prediction["id"])
        if linked:
            return {
                "status": "bet",
                "reason_codes": [],
                "reason": "已获得本联赛当日模拟下注名额",
                "bet_id": linked["id"],
                "execution_id": linked.get("execution_id"),
                "execution_status": "SETTLED" if linked.get("status") == "settled" else "EXECUTED",
                "risk_gate": linked.get("risk_gate"),
                "portfolio_candidate": linked.get("portfolio_candidate"),
            }
        if decision.get("status") != "bet":
            return {
                "status": decision.get("status") or "insufficient_data",
                "reason_codes": decision.get("reason_codes") or [],
                "reason": decision.get("reason") or "当前数据不足，未执行模拟下注",
                "bet_id": None,
                "execution_id": None,
                "execution_status": "REJECTED",
            }

        return {
            "status": "candidate",
            "reason_codes": [],
            "reason": "决策为下注，等待模拟执行窗口",
            "bet_id": None,
            "execution_id": None,
            "execution_status": "PENDING",
        }

    def _league_day_fixtures(self, fixture: dict[str, Any]) -> list[dict[str, Any]]:
        reader = getattr(self.repository, "list_fixtures", None)
        rows = reader(fixture["fixture_date"], fixture["fixture_date"], fixture.get("league_key")) if callable(reader) else []
        by_id = {str(item["id"]): item for item in rows}
        by_id[str(fixture["id"])] = fixture
        return list(by_id.values())

    def _league_day_candidates(
        self,
        prediction: dict[str, Any],
        fixture: dict[str, Any],
        fixtures: list[dict[str, Any]],
        context: dict[str, Any],
    ) -> list[tuple[dict[str, Any], dict[str, Any]]]:
        latest_reader = getattr(self.repository, "latest", None)
        rows: list[tuple[dict[str, Any], dict[str, Any]]] = []
        for grouped_fixture in fixtures:
            current = prediction if grouped_fixture["id"] == fixture["id"] else (
                latest_reader(grouped_fixture["id"], self.model_key, self.competition_id)
                if callable(latest_reader) else None
            )
            if current:
                candidate_context = (
                    context
                    if grouped_fixture["id"] == fixture["id"]
                    else grouped_fixture.get("evidence") or {}
                )
                current = deepcopy(current)
                _complete_candidate_decision(current, candidate_context, self.repository)
            if not current:
                continue
            candidates = build_candidates(
                current,
                grouped_fixture,
                self.portfolio_config,
                historical_clv=self._historical_clv(),
            )
            if candidates:
                current["portfolio_candidate"] = candidates[0].to_dict()
                rows.append((current, grouped_fixture))
        return sorted(
            rows,
            key=lambda item: (
                -float((item[0].get("portfolio_candidate") or {}).get("priority") or 0),
                -float((item[0].get("portfolio_candidate") or {}).get("candidate_score") or 0),
                str((item[0].get("portfolio_candidate") or {}).get("model_key") or ""),
                str(item[0].get("id") or ""),
            ),
        )

    def _league_day_bets(self, fixture_date: str, league_key: Any) -> list[dict[str, Any]]:
        return [
            item for item in self.repository.bets(
                fixture_date=fixture_date,
                model_key=self.model_key,
                competition_id=self.competition_id,
            )
            if item.get("league_key") == league_key
        ]

    def _historical_clv(self) -> float | None:
        values = [
            float(item["clv"])
            for item in self.repository.bets(
                status="settled",
                model_key=self.model_key,
                competition_id=self.competition_id,
            )
            if item.get("clv") is not None
        ]
        return round(sum(values) / len(values), 6) if values else None

    def _place_candidate(
        self,
        prediction: dict[str, Any],
        fixture: dict[str, Any],
    ) -> dict[str, Any] | None:
        return self._place_portfolio_candidate(prediction, fixture)

    def _canonical_stake(
        self,
        candidate: dict[str, Any],
        fixture: dict[str, Any],
        *,
        exclude_bet_id: str | None = None,
    ) -> float:
        bets = self.repository.bets(model_key=self.model_key, competition_id=self.competition_id)
        account_bets = [item for item in bets if item.get("id") != exclude_bet_id]
        transactions = [
            item
            for item in self.repository.bankroll_transactions(self.model_key, self.competition_id)
            if item.get("reference_id") != exclude_bet_id
        ]
        snapshot = exposure_snapshot(
            account_bets,
            transactions,
            fixture_date=fixture.get("fixture_date"),
            league_key=fixture.get("league_key"),
        )
        gate = risk_gate(
            candidate,
            snapshot["equity"],
            daily_exposure=snapshot["daily_exposure"],
            league_exposure=snapshot["league_exposure"],
            total_exposure=snapshot["total_exposure"],
            drawdown=float(self.summary().get("max_drawdown") or 0),
            config=self.portfolio_config,
        )
        return float(gate["allowed_stake"] if gate["status"] == "PASS" else 0.0)

    def _place_portfolio_candidate(
        self,
        prediction: dict[str, Any],
        fixture: dict[str, Any],
    ) -> dict[str, Any] | None:
        candidate = prediction.get("portfolio_candidate")
        if not isinstance(candidate, dict):
            candidates = build_candidates(
                prediction,
                fixture,
                self.portfolio_config,
                historical_clv=self._historical_clv(),
            )
            candidate = candidates[0].to_dict() if candidates else None
        if not candidate:
            return None
        all_bets = self.repository.bets(competition_id=self.competition_id)
        account_bets = [item for item in all_bets if item.get("model_key") == self.model_key]
        transactions = self.repository.bankroll_transactions(self.model_key, self.competition_id)
        account_snapshot = exposure_snapshot(
            account_bets,
            transactions,
            fixture_date=fixture.get("fixture_date"),
            league_key=fixture.get("league_key"),
        )
        fixed_stake = _fixed_stake(prediction)
        selected = select_portfolio(
            [candidate],
            account_snapshot=account_snapshot,
            existing_bets=account_bets,
            correlation_bets=all_bets,
            config=self.portfolio_config,
            drawdown=float(self.summary().get("max_drawdown") or 0),
            requested_stake=fixed_stake,
        )
        if not selected:
            return None
        selected_candidate = selected[0]
        stake = float(selected_candidate.get("stake") or 0)
        if stake <= 0:
            return None
        execution_id = f"execution:{uuid.uuid4()}"
        decision = prediction.get("decision") or {}
        payload = {
            "id": str(uuid.uuid4()),
            "execution_id": execution_id,
            "prediction_id": prediction["id"],
            "fixture_id": fixture["id"],
            "fixture_date": fixture["fixture_date"],
            "placed_at": datetime.now(UTC).isoformat(),
            "market": selected_candidate.get("market") or decision.get("market"),
            "selection": selected_candidate.get("selection") or decision.get("selection"),
            "handicap_line": selected_candidate.get("line"),
            "line_at_bet": selected_candidate.get("line"),
            "odds": selected_candidate.get("odds"),
            "bet_odds": selected_candidate.get("odds"),
            "stake": stake,
            "league_key": fixture.get("league_key"),
            "kickoff": fixture.get("kickoff"),
            "home_team": (fixture.get("home_team") or {}).get("name"),
            "away_team": (fixture.get("away_team") or {}).get("name"),
            "model_version": prediction.get("model_version"),
            "model_key": self.model_key,
            "competition_id": self.competition_id,
            "model_confidence": selected_candidate.get("confidence"),
            "model_probability": selected_candidate.get("model_probability"),
            "market_probability": selected_candidate.get("market_probability"),
            "edge": selected_candidate.get("edge"),
            "ev": selected_candidate.get("ev"),
            "expected_edge": selected_candidate.get("ev"),
            "risk_score": selected_candidate.get("risk_score"),
            "data_quality": selected_candidate.get("data_quality"),
            "odds_age_minutes": selected_candidate.get("odds_age_minutes"),
            "candidate_score": selected_candidate.get("candidate_score"),
            "raw_model_probability": selected_candidate.get("raw_model_probability"),
            "probability_source": selected_candidate.get("probability_source"),
            "market_prior_probability": selected_candidate.get("market_prior_probability"),
            "llm_keep_weight": selected_candidate.get("llm_keep_weight"),
            "shrinkage_status": selected_candidate.get("shrinkage_status"),
            "correlation_group": selected_candidate.get("correlation_group") or fixture.get("id"),
            "bookmaker": selected_candidate.get("bookmaker"),
            "odds_snapshot_id": selected_candidate.get("odds_snapshot_id") or prediction.get("odds_snapshot_id"),
            "portfolio_selection": "selected",
            "risk_gate": selected_candidate.get("risk_gate"),
            "reason": decision.get("reason"),
            "reason_codes": decision.get("reason_codes") or [],
            "prediction_phase": prediction.get("phase") or "preliminary",
            "is_simulated": True,
        }
        placed = self.repository.place_bet(payload)
        if placed and callable(getattr(self.repository, "create_bet_execution", None)):
            self.repository.create_bet_execution(
                {
                    "execution_id": execution_id,
                    "prediction_id": placed["prediction_id"],
                    "fixture_id": placed["fixture_id"],
                    "fixture_date": placed.get("fixture_date"),
                    "model_key": placed.get("model_key"),
                    "competition_id": placed.get("competition_id"),
                    "market": placed.get("market"),
                    "selection": placed.get("selection"),
                    "line": placed.get("line_at_bet") or placed.get("handicap_line"),
                    "odds": placed.get("bet_odds") or placed.get("odds"),
                    "stake": placed.get("stake"),
                    "requested_at": placed.get("placed_at"),
                    "executed_at": placed.get("placed_at"),
                    "status": "EXECUTED",
                    "source": "paper",
                    "payload": placed,
                }
            )
        return placed

    def summary(self) -> dict[str, Any]:
        bets = self.repository.bets(model_key=self.model_key, competition_id=self.competition_id)
        settled = [item for item in bets if item.get("status") == "settled"]
        open_bets = [item for item in bets if is_active_bet(item.get("status"))]
        total_staked = round(sum(float(item["stake"]) for item in bets), 2)
        settled_staked = round(sum(float(item["stake"]) for item in settled), 2)
        total_returns = round(sum(float(item.get("return_amount") or 0) for item in settled), 2)
        transactions = self.repository.bankroll_transactions(self.model_key, self.competition_id)
        account = exposure_snapshot(bets, transactions)
        balance = account["cash_balance"]
        open_exposure = account["open_exposure"]
        realized_profit = round(sum(float(item.get("net_profit") or 0) for item in settled), 2)
        profitable = sum(1 for item in settled if float(item.get("net_profit") or 0) > 0)
        decided = sum(1 for item in settled if item.get("settlement_result") != "push")
        betting_drawdown = calculate_drawdown(_equity_curve(settled, transactions, self.initial_bankroll), self.initial_bankroll)
        return {
            "initial_balance": self.initial_bankroll,
            "balance": balance,
            "cash_balance": balance,
            "equity": account["equity"],
            "net_profit": realized_profit,
            "total_staked": total_staked,
            "settled_staked": settled_staked,
            "total_returns": total_returns,
            "open_exposure": open_exposure,
            "roi": round(realized_profit / settled_staked, 4) if settled_staked else 0.0,
            "hit_rate": round(profitable / decided, 4) if decided else 0.0,
            "bet_count": len(bets),
            "settled_count": len(settled),
            "open_count": len(open_bets),
            "max_drawdown": betting_drawdown,
            "equity_curve": _equity_curve(settled, transactions),
            "is_simulated": True,
            "model_key": self.model_key,
            "competition_id": self.competition_id,
            "active_exposure": open_exposure,
            "total_exposure": account["total_exposure"],
            "drawdown_limit": self.portfolio_config.max_drawdown,
            "risk_gate_status": "FAIL" if betting_drawdown >= self.portfolio_config.max_drawdown else "PASS",
            "portfolio_policy": {
                "min_edge": self.portfolio_config.min_edge,
                "min_ev": self.portfolio_config.min_ev,
                "stake_fraction": self.portfolio_config.stake_fraction,
                "max_single_bet_fraction": self.portfolio_config.max_single_bet_fraction,
                "max_daily_exposure": self.portfolio_config.max_daily_exposure,
                "max_league_exposure": self.portfolio_config.max_league_exposure,
                "max_total_exposure": self.portfolio_config.max_total_exposure,
                "max_drawdown": self.portfolio_config.max_drawdown,
            },
        }


def _complete_candidate_decision(
    prediction: dict[str, Any],
    context: dict[str, Any],
    repository: Any | None = None,
) -> None:
    odds = context.get("odds")
    snapshot_id = prediction.get("odds_snapshot_id")
    reader = getattr(repository, "odds_snapshot", None) if repository is not None else None
    if snapshot_id and callable(reader):
        snapshot = reader(str(snapshot_id))
        if snapshot and isinstance(snapshot.get("payload"), dict):
            odds = snapshot["payload"]
    prediction["market_assessment"] = assess_markets(prediction, odds)
    prediction["market_assessment"]["odds_snapshot_id"] = snapshot_id


def _bet_matches_candidate(
    bet: dict[str, Any],
    prediction: dict[str, Any],
    *,
    expected_stake: float | None = None,
) -> bool:
    decision = prediction.get("decision") or {}
    candidate = prediction.get("portfolio_candidate") or {}
    expected = candidate.get("ev")
    stored_expected = bet.get("ev")
    return bool(
        bet.get("status") == "placed"
        and bet.get("market") == decision.get("market")
        and bet.get("selection") == decision.get("selection")
        and abs(float(stored_expected or 0) - float(expected or 0)) < 0.0001
        and (
            expected_stake is None
            or abs(float(bet.get("stake") or 0) - expected_stake) < 0.0001
        )
    )


def _fixture_started(fixture: dict[str, Any]) -> bool:
    if fixture.get("status") != "scheduled":
        return True
    try:
        kickoff = datetime.fromisoformat(str(fixture.get("kickoff") or "").replace("Z", "+00:00"))
        if kickoff.tzinfo is None:
            kickoff = kickoff.replace(tzinfo=UTC)
    except ValueError:
        return True
    return kickoff <= datetime.now(UTC)


def _equity_curve(
    settled_bets: list[dict[str, Any]],
    transactions: list[dict[str, Any]],
    initial_bankroll: float = INITIAL_BANKROLL,
) -> list[dict[str, Any]]:
    initial_at = transactions[0].get("created_at") if transactions else None
    points = [{"at": initial_at, "balance": initial_bankroll}]
    balance = initial_bankroll
    for bet in sorted(settled_bets, key=lambda item: (item.get("settled_at") or "", item["id"])):
        balance = round(balance + float(bet.get("net_profit") or 0), 2)
        points.append({"at": bet.get("settled_at"), "balance": balance, "bet_id": bet["id"]})
    return points


class DualBankrollService:
    """Aggregate model candidates before account-level simulated execution."""

    def __init__(self, services: dict[str, BankrollService], competition_id: str) -> None:
        self.services = services
        self.competition_id = competition_id

    def place_for_prediction(self, prediction: dict[str, Any], fixture: dict[str, Any], context: dict[str, Any]) -> dict[str, Any] | None:
        model_key = prediction.get("model_key") or (prediction.get("ai") or {}).get("provider") or "deepseek"
        service = self.services.get(model_key)
        return service.place_for_prediction(prediction, fixture, context) if service else None

    def place_for_predictions(
        self,
        predictions: list[dict[str, Any]],
        fixture: dict[str, Any],
        context: dict[str, Any],
        additional_candidates: Iterable[Any] | None = None,
    ) -> list[dict[str, Any]]:
        by_prediction_id = {str(prediction.get("id")): prediction for prediction in predictions}
        candidate_entries: list[tuple[Any, BankrollService, dict[str, Any]]] = []
        for prediction in predictions:
            model_key = prediction.get("model_key") or (prediction.get("ai") or {}).get("provider") or "deepseek"
            service = self.services.get(model_key)
            if service is None:
                continue
            candidate = service.candidate_for_prediction(prediction, fixture, context)
            if candidate is not None:
                candidate_entries.append((candidate, service, prediction))
            else:
                # A later odds/lineup refresh can invalidate a previously
                # placed open bet. Release that model's fixture exposure so
                # the next valid candidate does not inherit a stale position.
                repository = getattr(service, "repository", None)
                discard = getattr(repository, "discard_open_fixture_bets", None)
                if callable(discard):
                    discard(fixture["id"], str(model_key), self.competition_id)
        # The existing baseline is a candidate input only; it never creates a prediction row.
        for prediction in predictions:
            # A Poisson baseline may explain a degraded forecast, but it must
            # not create an automatic bet when the configured AI model failed.
            if (prediction.get("ai") or {}).get("status") != "completed":
                continue
            baseline_service = self.services.get(str(prediction.get("model_key") or "deepseek"))
            if baseline_service is None:
                continue
            poisson = baseline_service.candidate_for_poisson(prediction, fixture, context)
            if poisson is not None and _follows_ai_direction(prediction, poisson):
                candidate_entries.append((poisson, baseline_service, prediction))
                break
        fallback_service = next(iter(self.services.values()), None)
        fallback_prediction = predictions[0] if predictions else {}
        for candidate in additional_candidates or []:
            service = self.services.get(str(_candidate_value(candidate, "model_key"))) or fallback_service
            if service is None:
                continue
            prediction = by_prediction_id.get(
                str(_candidate_value(candidate, "prediction_id")),
                fallback_prediction,
            )
            candidate_entries.append((candidate, service, prediction))
        selected = select_best_candidates([entry[0] for entry in candidate_entries])
        selected_ids = {id(candidate) for candidate in selected}
        bets: list[dict[str, Any]] = []
        for candidate, service, prediction in candidate_entries:
            if id(candidate) not in selected_ids:
                continue
            fixed_stake = _fixed_stake(context)
            if bet := service.place_for_candidate(prediction, fixture, candidate, fixed_stake=fixed_stake):
                bets.append(bet)
        return bets

    def select_portfolio_candidates(self, candidates: list[Any]) -> list[Any]:
        """Expose the shared global candidate selection boundary for callers/tests."""

        return select_best_candidates(candidates)

    def execution_for_prediction(self, prediction: dict[str, Any], fixture: dict[str, Any]) -> dict[str, Any]:
        model_key = prediction.get("model_key") or (prediction.get("ai") or {}).get("provider") or "deepseek"
        service = self.services.get(model_key)
        if service:
            return service.execution_for_prediction(prediction, fixture)
        return {
            "status": "insufficient_data",
            "reason_codes": ["risk_limit"],
            "reason": "未找到对应模型的模拟账户",
            "bet_id": None,
        }

    def summary(self) -> dict[str, Any]:
        accounts = {key: service.summary() for key, service in self.services.items()}
        primary = accounts.get("deepseek") or next(iter(accounts.values()), {})
        return {
            **primary,
            "competition_id": self.competition_id,
            "accounts": accounts,
            "is_simulated": True,
        }


def _candidate_gate_diagnosis(
    prediction: dict[str, Any],
    fixture: dict[str, Any],
    config: PortfolioConfig,
    repository: Any | None = None,
) -> dict[str, Any]:
    """Explain which portfolio gates the fixture's best candidate failed."""

    generic = {
        "reason_codes": ["portfolio_filter"],
        "reason": "候选未同时满足 Portfolio 的 Edge、EV、数据质量或赔率新鲜度门槛",
    }
    working = deepcopy(prediction)
    _complete_candidate_decision(working, fixture.get("evidence") or {}, repository)
    scored = [
        candidate
        for row in (working.get("market_assessment") or {}).get("markets") or []
        if (candidate := candidate_from_market_row(working, fixture, row, config)) is not None
    ]
    if not scored:
        return generic
    best = max(scored, key=lambda item: item.candidate_score)
    reasons = candidate_gate_reasons(best, config)
    if not reasons:
        return generic
    return {
        "reason_codes": reasons,
        "reason": "；".join(_gate_detail(code, best, config) for code in reasons),
    }


def _gate_detail(code: str, candidate: BetCandidate, config: PortfolioConfig) -> str:
    if code == "edge_below_threshold":
        return f"Edge {candidate.edge * 100:.1f}% 低于门槛 {config.min_edge * 100:.0f}%"
    if code == "implausible_edge":
        return f"Edge {candidate.edge * 100:.1f}% 超出合理上限 {config.max_plausible_edge * 100:.0f}%，疑似数据异常"
    if code == "ev_below_threshold":
        return f"EV {candidate.ev * 100:.1f}% 低于门槛 {config.min_ev * 100:.0f}%"
    if code == "implausible_ev":
        return f"EV {candidate.ev * 100:.1f}% 超出合理上限 {config.max_plausible_ev * 100:.0f}%，疑似数据异常"
    if code == "data_quality_below_threshold":
        return f"数据质量 {candidate.data_quality * 100:.0f}% 低于门槛 {config.min_data_completeness * 100:.0f}%"
    if code == "odds_age_missing":
        return "赔率缺少可靠的更新时间"
    if code == "odds_age_stale":
        return f"赔率已 {candidate.odds_age_minutes:.0f} 分钟未更新，超过 {config.max_odds_age_minutes:.0f} 分钟门槛"
    return code
